# sysctl.conf
our server-side sysctl.conf kernel parameters, as currently deployed
