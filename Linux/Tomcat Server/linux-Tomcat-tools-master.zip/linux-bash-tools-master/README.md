# linux-bash-tools
Linux系统Shell脚本工具

## 目录
ScanLogAndSendMail.py : 扫描tomcat日志并发送Email(python)

tomcat-monitor.sh : tomcat进程监控脚本

oomscore.sh : 打印当前系统上 oom_score 分数最高（最容易被 OOM Killer 杀掉）的进程

post-receive.sh: git push 钩子脚本 发送通知Email 配置教程见：[Setting Up Git Commit Email Notifications](http://www.systutorials.com/1473/setting-up-git-commit-email-notification/)

